/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=48x13 ponglogo ponglogo.png 
 * Time-stamp: Thursday 04/02/2020, 17:28:20
 * 
 * Image Information
 * -----------------
 * ponglogo.png 48@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PONGLOGO_H
#define PONGLOGO_H

extern const unsigned short ponglogo[624];
#define PONGLOGO_SIZE 1248
#define PONGLOGO_LENGTH 624
#define PONGLOGO_WIDTH 48
#define PONGLOGO_HEIGHT 13

#endif

