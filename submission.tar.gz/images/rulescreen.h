/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 rulescreen rulescreen.png 
 * Time-stamp: Sunday 03/29/2020, 03:44:22
 * 
 * Image Information
 * -----------------
 * rulescreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RULESCREEN_H
#define RULESCREEN_H

extern const unsigned short rulescreen[38400];
#define RULESCREEN_SIZE 76800
#define RULESCREEN_LENGTH 38400
#define RULESCREEN_WIDTH 240
#define RULESCREEN_HEIGHT 160

#endif

