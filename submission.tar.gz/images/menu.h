/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 menu menu.png 
 * Time-stamp: Thursday 04/02/2020, 17:17:48
 * 
 * Image Information
 * -----------------
 * menu.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MENU_H
#define MENU_H

extern const unsigned short menu[38400];
#define MENU_SIZE 76800
#define MENU_LENGTH 38400
#define MENU_WIDTH 240
#define MENU_HEIGHT 160

#endif

