#ifndef IMAGES_H

#include "images/ponglogo.h"
#include "images/garbage.h"
#include "images/endscreen.h"
#include "images/menu.h"
#include "images/rulescreen.h"

#endif